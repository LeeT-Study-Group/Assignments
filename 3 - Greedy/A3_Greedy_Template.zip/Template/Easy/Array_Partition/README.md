# Array Partition
Link: [Array Partition](https://leetcode.com/problems/array-partition/)
