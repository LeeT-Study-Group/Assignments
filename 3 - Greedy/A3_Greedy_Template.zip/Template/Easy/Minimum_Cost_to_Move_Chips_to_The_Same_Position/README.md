# Minimum Cost to Move Chips to The Same Position
Link: [Minimum Cost to Move Chips to The Same Position](https://leetcode.com/problems/minimum-cost-to-move-chips-to-the-same-position/)
