# Assign Cookies
Link: [Assign Cookies](https://leetcode.com/problems/assign-cookies/)
