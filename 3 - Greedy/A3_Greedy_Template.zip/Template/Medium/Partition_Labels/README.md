# Partition Labels
Link: [Partition Labels](https://leetcode.com/problems/partition-labels/)
