# Score After Flipping Matrix
Link: [Score After Flipping Matrix](https://leetcode.com/problems/score-after-flipping-matrix/)
