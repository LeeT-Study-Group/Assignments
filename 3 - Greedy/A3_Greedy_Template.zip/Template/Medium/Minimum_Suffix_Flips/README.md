# Minimum Suffix Flips
Link: [Minimum Suffix Flips](https://leetcode.com/problems/minimum-suffix-flips/)
