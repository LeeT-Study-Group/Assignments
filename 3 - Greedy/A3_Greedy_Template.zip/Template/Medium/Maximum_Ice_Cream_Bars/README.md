# Maximum Ice Cream Bars
Link: [Maximum Ice Cream Bars](https://leetcode.com/problems/maximum-ice-cream-bars/)
