# Increasing Order Search Tree
Link: [Increasing Order Search Tree](https://leetcode.com/problems/increasing-order-search-tree/)
