# Search in a Binary Search Tree
Link: [Search in a Binary Search Tree](https://leetcode.com/problems/search-in-a-binary-search-tree/)
