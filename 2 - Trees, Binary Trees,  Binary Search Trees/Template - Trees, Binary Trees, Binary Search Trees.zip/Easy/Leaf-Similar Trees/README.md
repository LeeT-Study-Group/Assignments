# Leaf-Similar Trees
Link: [Leaf-Similar Trees](https://leetcode.com/problems/leaf-similar-trees/)
