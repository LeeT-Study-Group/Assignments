# Balance a Binary Search Tree
Link: [Balance a Binary Search Tree](https://leetcode.com/problems/balance-a-binary-search-tree/)
