# Insert into a Binary Search Tree
Link: [Insert into a Binary Search Tree](https://leetcode.com/problems/insert-into-a-binary-search-tree/)
