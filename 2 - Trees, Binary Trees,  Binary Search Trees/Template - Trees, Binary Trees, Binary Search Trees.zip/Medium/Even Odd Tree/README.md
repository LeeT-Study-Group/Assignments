# Even Odd Tree
Link: [Even Odd Tree](https://leetcode.com/problems/even-odd-tree/)
